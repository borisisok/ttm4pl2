#!/usr/bin/perl

$reversed= 1;

$FCOLS= 8;				# number of columns on paper tape

	print "# Paper tape 8x8 font data, generated from \n";
	print "# .DWG file. */\n";
	print "%FONT= (\n";

	$i= 0;				# index to store rows of bits
	$lineno= 0;			# input file line number
	$charno= 32;			# table starts here

	while (<>) {
		chomp;
		++$lineno;		# count lines for error reports
		next if /^$/;		# skip blank lines,
		next if /^;/;		# skip comments,
		if (/^char/) {		# if start of next character
			print "ERROR: 'char' before character complete! Line #", $lineno, "\n"
				if $i > 0;
		}
		next if ! /^[-x]/;	# if - or x (bit pattern) --

		tr/ //d;		# remove all spaces
		tr/-/0/;		# translate - to 0
		tr/x/1/;		# and x to 1
		$a[$i]= $_;		# add to array
		next if ++$i < $FCOLS;	# get 8 rows

#	|
#	V
#i=0	10000000000000		1 * 2**0 = 1 +
#i=1	10000000000000		1 * 2**1 = 2 +
#i=2	00000000000000		0 * 2**2 = 0 +
#...	...			...	   ... +
#i=n	10000000000000		1 * 2**7 = 128
#
# Build a byte that is the sum of each left-most bit, binary-weighted. Each
# of these bytes is a paper-tape byte, or character bit column, eg. the
# previous data rotated CW.

		print "\n" if $charno % 32 == 0;
		print "\t";
		print "    \"$c\" => [";
		foreach $r (@a) {		# each row in character,
			@A= split //, $r;		# table of bits,
			@A= reverse (split //, $r) if $reversed;
			$byte= 0;
			foreach (@A) {
				$byte += $byte;		# shift left,
				$byte += (0 + $_);	# add bit
			}
			print "$byte, ";
		}
		print "],\n";
		++$charno;
		$i= 0;				# start over
	}
	print ");\n";			# terminate array


