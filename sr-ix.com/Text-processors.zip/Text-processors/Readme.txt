T2A -- Story Teller compiler
Tom Jennings
$Id: t2a.txt,v 1.1 2003/03/25 09:24:27 tomj Exp tomj $

See below for serial setup hints.

I've forgotten what t2a stands for. It's now the overarching
executor of the filters that produce paper-tape-stored stories
for the Story Teller components, as of this writing:

				tag	record type	filter
Human-readable leader		LEADER: T		n/a
Model 2 Teletype controller	TTY:	A		internal
Model 3, Tape Reader			n/a		n/a
Model 4, Strip Printer		STRIP:	S		internal
Model 7, Gallery Controller	n/a	n/a		n/a
Model 31, Vocalizer		SPEAK:	P		phoneme
Model 423, Robot Calculator and	CALC:	V		internal
	Writing Machine	(text)	WRITE:	X		text2X | squish-flu
	draw			DRAW:	X		flutools*



t2a processes a line-oriented input file, generally extention
.t2a. Each line begins with a tag that indicates the target device
(and the filter required to process it) and contains ASCII text
and meta commands.

The payload portion of each input line is passed through a filter,
via stdin and stdout, and upon return to t2a, is wrapped in WPS
record format and output to stdout, ready for punching on tape.

All of the filters reside in WPS/Text-processors, but are executed
out of the path.

t2a passes input text to a filter that translates it for a specific
device. Each filter does device-specific text translations from
stdin to stdout.

ERRATA

Using flutools to process EPS to X records still requires manual
intervention.


SERIAL PORT SETUP

For linux (up to SuSE 9.1, 2.6 kernel) /dev/ttyS0 works fine. The
GNT punch HIGH speed is 1200, and needs hardware handshake. LOW
speed (300?)  may not.

The easiest way to set up the serial port is minicom. Set to
1200 baud, hardware handshake, 8n1, exit-without-reset, and the
port settings remain.  Simple output redirection from t2a works:

$ t2a file.t2a > /dev/ttyS0

waitCTS is a filter that talks to the serial port and waits for
CTS to go true then false for each character, and allows plugging
/dev/ttySx directly into the serial distributor.



INPUT SOURCE FILE FORMAT:

The input is line oriented, with a tag beginning in column 0 that
always ends with ":". There is no space compression or clipping
of any kind.

Input lines are passed to the filters as-is after the tag is
chopped off and metas expanded (see below). Input lines have an
implicit newline at the end; the \NOEOL directive suppresses this.

All of the filters are expected to handle input more or less the
same, as appropriate for the target device. Some, like text2X,
accept embedded directives (see below) for device-specific control.
These directives pass through t2a as ordinary text.


EXAMPLE:

; Comment
# Comment
LEADER: Test tape.
TTY: Now is the time,\NOEOL
SPEAK:Now is the time,\PAUSE
WRITE:Now is the time,\NOEOL
TTY: and this is the place,\NOEOL
SPEAK:I feel displaced,
TTY: I can't feel my hands.\n\n
WRITE:I can't feel my hands.
SPEAK:Are we there yet?
TTY:\BELL\NOEOL\OFF



METAs

Meta text map to a single control character that performs some
function within the filter. No attempt is made to prevent silly
code combinations, and some metas map to the same control code.
The t2a code is the authoritative source, but the following list
is likely:

        "/NOEOL" =>    "\\",           # suppress /r/n
        "/PAUSE" =>    "\cY",          # pause (Model 31)
        "/LONGPAUSE" =>"\cV",          # long pause (Model 31)
        "/DEMO1" =>    "\cR",          # demo on (Model 31)
        "/DEMO2" =>    "\cT",          # demo off (Model 31)

        "/BELL" =>     "\a",           # bell (Models 2, 4)
        "/OFF" =>      "\cN",          # motor off (Models 2, 4)
        "/FIGS" =>     "\c[",          # FIGS (ESC) (Models 2, 4)
        "/LTRS" =>     "\c_",          # LTRS (US) (Models 2, 4)

        "/EJECT" =>    "\cV",          # eject strip (Model 4)
        "/CUT" =>      "\f",           # cut (Model 4)

        "/FF" =>       "\f",           # FF (Model 423, X)
        "/RLF" =>      "\cV",          # reverse LF (VT) (Model 423, X)
	"//" =>		"/",           # the char itself




SPECIFIC FILTER DOCUMENTATION

Each of the filters accepts line-oriented input to stdin,
and produces device-specific data to stdout. In general, all
printable characters are accepted (and translated to acceptable
characters in the filter or in the device) and control codes,
except those above are generally ignored.

Many filters generate many lines of output for each line of input;
t2a makes each output line one WPS record. The filters generally
make an effort to produce short (< 40 character) records.

All of the filter support -h and -q command line options,
often more.



internal t2a filter
-------------------
Record types A, S, V

The internal filter handles the simplest translations; it expands
the meta macros and outputs the text. If newline suppression is
required, use /NOEOL.



text2X
------
record type X

Translates 128ASCII to Flutterwumper commands. The analog plotter
as text output device leaves a lot to be desired.

The worst problem is that there is so little usable space, and
that it's hard to keep track of pen position on the paper. It
is impossible for the filter to know where the pen is in between
invokations; directives help, with a lot of planning.

A scale factor determines character size; less than 6 is pretty
lousy due to slop in the pen mechanism, and a generally E-W dab
when the pen drops.

Characters are proportional width, except A-Z and 0-9 are fixed
width.

You are essentially required to pass pen position into the filter
with directives, or to home the plotter. The filter assumes that
the pen is home, at the upper left corner, unless told otherwise.

Text character-wraps to the next line; bottom line wraps to top.

text2X is very good about minimizing motion.


t2a directives:

/NOEOL
Suppresses newline at end of line. Annoyingly, perl stdin adds
newline, if appending to a line is needed this directive is
required.

/RLF
Reverse linefeed; generates ASCII VT character. Goes up one line.
Behaves badly if at top line.

/FF
Same as /HOME, below.

/BS
Moves to the left, the width of the most recently printed
character.  Only. Won't move backwards through a list of
variably-widthed characters.



Supports additional directives:

/POS X,Y

Place plotter at X,Y position. X is E-W, left to right, 0 -
1000. Y is N-S, up to down, 0 - 700.

/SCALE 1-24

Default is 8. Scales output characters and spacing. 6 - 10
looks best.

/HOME

Homes the plotter.

/LINE n

Tells the filter that the pen is at the given "line" number, at
the current scale factor. Column -- X -- is a problem, because
chars are variable width.




squish-flu
----------
record type X

This filter performs run-length encoding on Flutterwumper output,
compressing command streams about 30:1. Which is good, since the
streams are so damn large.


phoneme
-------
record type P

-P for phoneme output

/PAUSE
/LONGPAUSE

Translates text to phonemes for Model 31; General Instrument
SPO256AL2 opcodes biased with ASCII space, unless -P. Input text
is canonicalized (whitespace, punctuation compressed, etc) and
output line by line. Only printable text is translated; control
codes are passed through as-is, therefore /PAUSE etc translations
work as specified.

(Though specials (control codes, `, etc) probably can appear
anywhere it's probably good practice to put them at word breaks.)



