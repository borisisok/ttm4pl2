#include <stdlib.h>
#include <stdio.h>

/*

a2ita-set file

Converts the input ASCII stream to an output ASCII stream, with all
characters that do not exist in ITA2/US-TTY to their closest GRAPHICAL
equivelants that exist in ITA2.

For pre-converting ASCII art files to be compatible with an ITA2/USTTY
teletype.

Otherwise the resulting output will be useless.

Unlike A2B and B2A, this works as a filter since it's all ASCII.

Tom Jennings
mru 29 Aug 1999

*/

char table[] = " 1\"#S8&,()YX,-./0123456789:;(-)?WABCDEFGHIJKLMNOPQRSTUVWXYZ(/)--,ABCDEFGHIJKLMNOPQRSTUVWXYZ(/)--";

FILE *fi;					/* input file */

int
main(argc, argv)
int argc;
char *argv[];
{
int c;

	if (argc < 2) {
		fprintf (stderr, "a2ita-set -- ASCII to ITA-subset ASCII.\n");
		fprintf (stderr, "Tom Jennings tomj@wps.com\n");
		return(1);
	}
	if ((fi= fopen(argv[1], "rb")) == NULL) {	/* MODE = READ-ONLY, BINARY! */
		printf ("File %s doesn't exist!\n", argv[1]);
		exit(1);
	}
	while ((c= fgetc(fi)) != EOF) {			/* for each character in the input file, */
		if (c >= ' ') c= table[c - 32];		/* translate printable */
		if (fputc(c, stdout) == EOF) {		/* write to output file */
			fprintf (stderr, "ERROR: Write to stdout failed! (disk full?)\n");
			break;
		}
	}
	fclose(fi); 
	return(0);
}

