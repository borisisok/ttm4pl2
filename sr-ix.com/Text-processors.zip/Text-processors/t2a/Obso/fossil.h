
/* Prototypes for FOSSIL.C. */

unsigned int14(char, char, unsigned);
void init(unsigned, char);
unsigned baud(unsigned);
void uninit(void);

void lower_dtr(void);
void raise_dtr(void);
void _mbreak(void);		/* send break */
unsigned _cd(void); 		/* true if modem status .AND. cd_bit */

unsigned _mbusy(void);		/* true if output buffer busy */
unsigned _mconostat(void);	/* true if room in output buffer */
void _mconout(char);		/* put char into output buffer */
void _mflush(void);		/* throw away output buffer */

unsigned _mconstat(void);	/* true if char to read */
unsigned _mconin(void);		/* read char (wait if none) */


