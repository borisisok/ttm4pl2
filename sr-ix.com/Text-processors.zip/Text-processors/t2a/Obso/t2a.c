#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define FALSE (0)
#define TRUE (!FALSE)

#define BEL 7
#define CR 13
#define DC2 18
#define DC4 20
#define EM 25
#define EOT 4
#define ESC 27
#define ETX 3
#define FF 12
#define NUL 0
#define SO 14
#define SOH 1
#define STX 2
#define SUB 26
#define US 31
#define VT 11


#include "t2a.h"
#include "english.c"
#include "font.h"

/* This started out life as a hack of John Wasser's PHONEME program;
it produced allophone opcodes from text. It has since expanded into the
generalized data processor for WPS format records.

Assuming -S is given, lines in the input file are processed according
to the first character in each line, where the first character (A, T, P,
etc) indicates the type of record to create with the contents of that line
(A, T, P record, etc).

Note that T records do not conform to the standard; without NULs embedded
they just don't look right.

*/


/* !!!! start of PHONEME.C */

/* Tom Jennings

26 Mar 2002
Added type S for strip printer.

mru 17 Sep 1999
All but arecd() issue a NUL before each record; added NUL to arecd().
The model 7 gallery controller uses CTS to control the Story Teller,
and needs to halt data flow immediately after each record (EOT), and
the extra character-time is good cheap insurance.

mru 21 Aug 1999
Added \p (2 sec pause) and \v (15 sec pause) support in precd.

mru 1 Apr 1999
Was outputting STX at end of data, rather than ETX! 

mru 7 Mar 1999
Added \n, \r, \b support in arecd.

mru 25 Feb 1999
Added support for multiple streams; -S flags using the first character
of each line to determine which stream the line of text goes to; P for
phonemes A for ASCII.

mru 21 Feb 1999
Output format conforms to character stream file format. A new file is
output every line (newline), with a minimum record length.

Added "spell mode"; backquote ` toggles spell-mode on and off. When true,
words are spelled out.

new 31 Dec 98
English text to allophone translation for the General Instrument
SPO256-AL2.  An minor adaptation of John Wasser's PHONEME software. The
allophone set has been expanded from the original 41 to a larger
subset of the 64 allophones; I very carefully exploited the different
opcodes for similar sounds, eg. the voiced stops (three 'G's, etc) --
though I have to say this chip really sucks at voiced stops, practically
unintelligible. Never mind the cultural imperialism embodied in silicon --
it is utterly incapable of making gutteral stops, inflections, dipthongs,
etc, or 'speaking' anythnig but variants of english.

The character-to-phoneme lookup tables have been massively updated. The
things that were Big Deals in 1985 are incomprehensibly insignifigant
today; namely table size (memory and CPU search time). The table had many
errors (still have many more) and I'm sure I introduced many new errors,
but it speaks signifigantly better now.

A stream of ASCII characters is parsed via lookup table rules ("
'E' preceded by 'H' sounds like 'EH' " etc); strings of phonemes are
converted to SPO256-AL2 opcodes. Phonemes are simply looked up in a
table to produce the allophone opcode:

text		hello
phonemes	h EH l OW
opcodes		;'MU


Direct improvements include: pauses/silence handled more explicitly
(originally only one pause/silence period was used, inter-word
and inter-space); added many rules to use the allophones for the
position-dependent phonemes of the GI chip (eg. /TT1/ vs. /TT2/).

Finally, SPO256-AL2 allophone opcodes are output directly.



This is a down'n'dirty program now; I rolled all of the source files
into this main, except for english.h which is a #include. And I created
t2a.h for the prototypes which didn't exist in 1985.




The original README file. 


	                Final Version of
                ENGLISH TO PHONEME TRANSLATION
                           4/15/85

        Here it is one last time.  I have fixed all of the bugs I
        heard about and added a new feature or two (it now talks
        money as well as numbers).  I think that this version is
        good enough for most purposes.  I have proof-read the
        phoneme rules (found one bug) and made the program more
        "robust".  I added protection against the "toupper()"
        problem some people had with earlier versions.

        If you make a major addition (like better abbreviation
        handling or an exception dictionary) please send me a
        copy.  As before, this is all public domain and I make
        no copyright claims on it.  The part derived from the
        Naval Research Lab should be public anyway.  Sell it
        if you can!

                -John A. Wasser

Work address:
ARPAnet:        WASSER%VIKING.DEC@decwrl.ARPA
Usenet:         {allegra,Shasta,decvax}!decwrl!dec-rhea!dec-viking!wasser
Easynet:        VIKING::WASSER
Telephone:      (617)486-2505
USPS:           Digital Equipment Corp.
                Mail stop: LJO2/E4
                30 Porter Rd
                Littleton, MA  01460


   The files that make up this package are:

          english.c       Translation rules.
          phoneme.c       Translate a single word.
          parse.c         Split a file into words.
          spellwor.c      Spell an ASCII character or word.
          saynum.c        Say a cardinal or ordinal number (long int).

(tomj: All of the files mentioned above have been included in this single
source file; ENGLISH.C is included with a #include statement).

*/


static FILE *In_file;		/* text input */
static FILE *Out_file;		/* phonemes out */

/* We create P records reasonably frequently; it allows an
interrupted/repaired tape to play from the middle with minimal loss, and
allows interspersed A records. We use a high water/ low water threshold
to determine record size, but -- if A records are being produced, a P
record will be produced too on newline boundaries. (This allows syncing
A record data with the following P record). P records only start/stop
on newlines or if the local buffer becomes very full. */

#define MAX_LENGTH (512)	/* size of allophone, text buffers */
#define MINLEN (40)		/* minimum record size */
#define MAXLEN (MAX_LENGTH - 2)	/* maximum record size */

long count;			/* number of characters output */
unsigned precdlen = 0;		/* length of P record */
char phoflag = 0;		/* 1 == output ASCII phonemes */
char sflag = 1;			/* 1 == explicit streams */
char spellflag= 0;		/* 1 == spell everything; ` toggles */
char lastchar = '\0';		/* suppresses runs of newlines, see outchar() */
char forcetype = '\0';		/* A..z force generation of record type */
char text[MAX_LENGTH];		/* text for filetype A output */
unsigned tpos = 0;		/* index into text[] */

char recdtype[256];		/* recdtype[n]= 1 to include record type N */

static int Char, Char1, Char2, Char3;

/*
** main(argc, argv)
**	int argc;
**	char *argv[];
**
**	This is the main program.  It takes up to two file names (input
**	and output)  and translates the input file to phoneme codes
**	(see english.c) on the output file.
*/
int
main(argc, argv)
int argc;
char *argv[];
{
int i;
char stdinflag;

	for (i= 0; i < sizeof(recdtype); i++) 		/* enable all types */
		recdtype[i]= i;				/* table[char]= char */

	stdinflag= 0;					/* -- not found yet */

	i= 1;						/* I= command arg # */
	--argc;						/* skip prog name */
	if (argc < 1) {
error:		fprintf(stderr, "T2A -- WPS file format text processor. Generates a stream of \n");
		fprintf(stderr, "WPS file formatted data from an input text. Supports the \n");
		fprintf(stderr, "following record types: A (Model 2); T (papertape title); \n");
		fprintf(stderr, "P (Model 31); X (XYZ box), S (Model 4).\n");
		fprintf(stderr, "Try:\n");
  		fprintf(stderr, "    t2a [opt] filein fileout\n");
  		fprintf(stderr, "    stdout is used if fileout not specified\n");
  		fprintf(stderr, "    opts are:\n");
		fprintf(stderr, "    -XaBc exclude record types a, B, c from output\n");
		fprintf(stderr, "    -Fa   force entire input as record type a (no stream support)\n");
		fprintf(stderr, "    -T    output 6\" of NUL trailer (T records generate leader)\n");
		fprintf(stderr, "    -P    output ASCII phonemes instead of opcodes ONLY, no stream support\n");
		fprintf(stderr, "    --    read from stdin\n");
		exit(1);
	}
	while (*argv[i] == '-') {
		switch (*++argv[i]) {			/* process options */
			case 'f': case 'F':
				forcetype= *++argv[i];	/* save forced type */
				break;

			case 'x': case 'X':		/* exclude record(s) */
				while (*++argv[i]) 	/* for all following  */
					recdtype[*argv[i]]= 0;	/* clear flag */
				break;

			case 'p': case 'P':		/* output Phonemes */
				phoflag= 1; 
				sflag= 0;		/* disable streams */
				break;

			case '-':			/* -- stdin specifier */
				stdinflag= 1;
				break;
		}
		++i;					/* eat the -opt arg */
		--argc;	
	} 

/* Determine input file. */

	if (stdinflag) {
		In_file= stdin;				/* -- was specified, */
		if (Out_file != stdout) fprintf(stderr, "Enter text:\n");

	} else if (argc < 1) goto error;		/* none specified! */
	else if ((In_file= fopen(argv[i], "r")) == 0) {	/* if can't open, */
		fprintf(stderr, "ERROR: Can't open file \"%s\"\n\n", 
		    (char *)(argv[i]));
		goto error;
	}

/* Determine output file. */

	++i; --argc;					/* next arg, */
	if (argc < 1) Out_file= stdout;
	else if ((Out_file= fopen(argv[i], "w")) == 0) {/* if can't create, */
		fprintf(stderr, "ERROR: Can't create file \"%s\"\n\n", 
		    *argv[i]);
		goto error;
	}

	text[tpos= 0]= '\0';				/* input buffer empty */
	count= 0L;					/* total chars output */
	xlate_file();					/* translate file */
	if (Out_file != stdout) 
	    fprintf(stderr, "%lu characters output (%d'%d\" of tape)\n", 
	    (long)(0L+count), count / 120, (count / 10) % 12);
	return(0);
}




/* General Instrument SP0256-AL2 phonemes */

/* This table contains the GI phonemes and their numeric values. The
text is the phoneme name generated by John Wasser's PHONEME program,
the numeric values are the GI opcodes. */

struct _p2a {
	char *phoneme;
	char allophone;
} p2a[] = {
	{"IY",	0x13},	/* see */
	{"IH",	0x0c},	/* sit */
	{"EY",	0x14},	/* beige */
	{"EH",	0x07},	/* end, get */
	{"AE",	0x1a},	/* fat */
	{"AA",	0x18},	/* hot (father?) */
	{"AO",	0x17},	/* aught, lawn */
	{"OW",	0x35},	/* lone, beau */
	{"UH",	0x1e},	/* full, book */
	{"UW",	0x1f},	/* food, fool */
	{"ER",	0x34},	/* fir, murder */
	{"AX",	0x0f},	/* suck, about */
	{"AH",	0x0f},	/* but */
	{"AY",	0x06},	/* sky, hide */
	{"AW",	0x20},	/* out, how */
	{"OY",	0x05},	/* boy */

	{"h",	0x1b},	/* he */
	{"p",	0x09},	/* pow, pack */
	{"b",	0x3f},	/* business, back */
	{"t",	0x0d},	/* to, time */
	{"d",	0x21},	/* do, dime */
	{"k",	0x2a},	/* sky */
	{"g",	0x24},	/* got, goat */
	{"f",	0x28},	/* fault, food */
	{"v",	0x23},	/* vest, vault */
	{"TH",	0x1d},	/* ether, thin */
	{"DH",	0x36},	/* they, either */
	{"s",	0x37},	/* vest, Sue */
	{"z",	0x2b},	/* zoo */
	{"SH",	0x25},	/* ship, leash */
	{"ZH",	0x26},	/* azure, leisure */
	{"HH",	0x39},	/* hoe, how */
	{"m",	0x10},	/* milk, sum */
	{"n",	0x0b},	/* thin, sun */
	{"NG",	0x2c},	/* sung, anchor */
	{"l",	0x2d},	/* lake, laugh */
	{"w",	0x2e},	/* wear, wool */
	{"y",	0x19},	/* yes, young */
	{"r",	0x33},	/* rate */
	{"CH",	0x32},	/* church, char */
	{"j",	0x0a},	/* jar, dodge */
	{"WH",	0x30},	/* whig, where */
	{"P1",	0x00},	/* pause, 10ms */
	{"P2",	0x01},	/* pause, 30ms */
	{"P3",	0x02},	/* pause, 50ms */
	{"P4",	0x03},	/* pause, 100ms */
	{"P5",	0x04},	/* pause, 200ms */

	{"R1",	0x27},	/* reed */
	{"T1",	0x11},	/* part */
	{"EY",	0x36},	/* they */
	{"D1",	0x15},	/* could */
	{"U1",	0x16},	/* to */
	{"G3",	0x22},	/* wig */
	{"RR",	0x0e},	/* brain */
	{"K2",	0x08},	/* comb */
	{"K1",	0x29},	/* cant */
	{"XR",	0x2f},	/* pair */
	{"Y1",	0x31},	/* yes */
	{"R2",	0x34},	/* fir */
	{"N2",	0x38},	/* no */
	{"OR",	0x3a},	/* store */
	{"AR",	0x3b},	/* alarm */
	{"YR",	0x3c},	/* clear */
	{"G2",	0x3d},	/* guest */
	{"EL",	0x3e},	/* saddle */
	{"B2",	0x1c},	/* caleb */
	{"DT",	0x12},	/* they */
	{"", 0}		/* end of table */
};

/* Given a phoneme text string, convert to WPS allophone file format;
if -P was specified, simply output phonemes. */

void
outstring(s)
char *s;
{
struct _p2a *t;
char *q, p[3];

	q= s;						/* save for report */
	while (*s) {					/* until exhausted, */
		if (*s == ' ') {
			++s; continue;
		}
		if (isupper(*s)) {			/* A-Z* are two chars */
			p[0]= *s++; p[1]= *s++; p[2]= '\0';

		} else {				/* a-z* one char long */
			p[0]= *s++; p[1]= '\0';
		}

		for (t= p2a; *t-> phoneme; ++t) {	/* search for it */
			if (strcmp(t-> phoneme, p) == 0) {
				if (phoflag) fprintf(Out_file, " %s", p);
				else {
					outchar(t-> allophone + ' ');
					++precdlen;	/* another output */
				}
				break;
			}
		}
		if (! *(t-> phoneme)) {
			fprintf(stderr, "Phoneme \"%s\" in string \"%s\" not in allophone table!\n", p, q);
		}
	}
}

	
/* Output a character to the output file. */

void
outchar(c)
int c;
{
	fputc(c,Out_file);
	lastchar= c;					/* remember it, */
	++count;
}


int
makeupper(character)
int character;
{
	if (islower(character))
		return toupper(character);
	else
		return character;
}


/* This is the top of the text-file processing loop. Characters up
to CR/LF (as appropriate) are read into the buffer, and the first
character determines the record type. There are a number of crocks and
inefficiencies here, because this was coded not designed. */

void
xlate_file()
{
unsigned lineno;
char c;

	lineno= 1;
	while (fgets (text, MAX_LENGTH, In_file) != NULL) {
		Char= Char1= Char2= Char3= '\n';	/* prime the pump */
		tpos= 0;				/* restart new_char() */
		++lineno;
		if (forcetype) c= forcetype;		/* cmd line forced */
		else c= new_char();			/* else from input */
		c= recdtype[c];				/* excluded = 0 */
		switch (c) {				/* 1st char indicates */
			case '\n':			/* empty line, ignore */
			case '\r':			/* DOS file, ignore */
			case ';':			/* comment, ignore */
				break;

			case 'a': case 'A':
				new_char();		/* eat type char */
				arecd();		/* output as A recd, */
				break;

			case 's': case 'S':
				new_char();
				srecd();
				break;

			case 'p': case 'P':
				new_char();
				precd();
				break;

			case 't': case 'T':
				new_char();
				trecd();
				break;

			case 'x': case 'X':
				new_char();
				xrecd();
				break;

			case NUL:
				break;			/* excluded type */

			case EOF:
			default:
				if (Char < ' ') fprintf(stderr, "\nUnknown type (character \"%d\") in line %u\n", Char, lineno);
				if (Char >= ' ') fprintf(stderr, "\nUnknown type \"%c\" in line %u\n", Char, lineno);
				chomp text;
				fprintf(stderr, "Offending line is: [%s]\n", text);
				return;			/* DIE */
		}
	}
}

/* Return the next character from the line buffer, else EOF at end of
line. */

int
readchar()
{
char c;

	while (1) {
		c= text[tpos];				/* sample char, */
		if (c == '\0') return (EOF);		/* do not pass EOF! */
		++tpos;					/* char is eaten */
		if (c == '\r') continue;		/* ignore CR */
		return (c);
	}
}

/* If the cache is full of newline, time to prime the look-ahead again. If
an EOF is found, fill the remainder of the queue with EOF's.  */

char
new_char() {

	if ((Char == '\n') && (Char1 == '\n') && 
	    (Char2 == '\n') && (Char3 == '\n')) {	/* prime the pump */
		if ((Char= readchar()) == EOF) {
			Char1= Char2= Char3= EOF;
			return Char;
		}
		if (Char == '\n') return Char;

		if ((Char1= readchar()) == EOF) {
			Char2= Char3= EOF;
			return Char;
		}
		if (Char1 == '\n') return Char;

		if ((Char2= readchar()) == EOF) {
			Char3= EOF;
			return Char;
		}
		if (Char2 == '\n') return Char;

		Char3 = readchar();

	} else {
/* Buffer not full of newline, shuffle the characters and either get a
new one or propagate a newline or EOF.  */

		Char = Char1;
		Char1 = Char2;
		Char2 = Char3;
		if (Char3 != '\n' && Char3 != EOF)
			Char3 = readchar();
	}
	return Char;
}


/* Punch the line of text as a T record. */

void
trecd() {
int i;

	trailer(120, NUL);	/* some leader */
	outchar(SOH);		/* SOH header, */
	outchar('T');		/* record type */
	outchar(STX);		/* start of text */
	trailer(10, NUL);
	while (Char != EOF) {
		if (Char >= ' ') punch(Char);	/* convert and output, */
		new_char();
	}
	trailer(10, NUL);
	outchar(ETX);		/* end of text */
	outchar(EOT);		/* end of record */
	trailer(60, NUL);	/* some leader */
}

/* Output a run of some character */

void
trailer(n, c)
int n;
char c;
{

	while (n--) outchar(c);
}


/* Convert an ASCII character to a string of characters that draw the
character on 8-level paper tape. In the font table, all characters
are the same width, for ease in indexing, and are padded on the right
with NULs; there may be NULs buried in the font character, so a simple
output-til-NUL-read won't work. Instead, we find the width of the
character by counting the TRAILING NUL characters, and skipping those. */

void
punch(c)
char c;
{
int i, cols;
char v;

	if ((c < ' ') || (c > '~')) return;		/* only printable */
	cols= FCOLS;					/* calc number of  */
	while (--cols > 1) {				/* trailing nulls */
		if (font[c - 32][cols]) break;		/* found non-zero */
	}
	if (c == ' ') cols= 3;				/* space always 3 */
	++cols;						/* null after each*/

	for (i= 0; i <= cols; i++) {
		v= font[c - 32][i];
	/*	if (! v) v= 0x80;	*/		/* convert NUL to 128 */
		outchar(v);
	}
}

/* Output all of the text in the current line buffer as an S record.
Because this isn't a page printer, newline becomes four spaces. */

void
srecd() {

	outchar(NUL);					/* see 17 sep 99 mru */
	outchar(SOH);					/* ASCII SOH */
	outchar('S');					/* ASCII filetype */
	outchar(STX);					/* ASCII STX */
	for ( ; Char != EOF; new_char()) {
		switch (Char) {
			case '\\':
				new_char();		/* read next char, */
				switch (Char) {
				case 'r': outchar('\r'); break; /* CR */
				case 'n': outchar('\n'); break;	/* LF */
				case 'o': outchar(SO); break;	/* MOTOR OFF */
				case 'b': outchar(BEL); break;	/* ding */
				case 'k': outchar(VT); break;	/* eject */
				case 'l': outchar(FF); break;	/* cut paper */
				case '[': outchar(ESC); break;	/* FIGS */
				case '_': outchar(US); break;	/* LTRS */
				case 'y': outchar(EM); break;	/* pause */
				case '\\': outchar ('\\'); break;

				default: break;			/* \x ignored */
				}
				break; /* case '\\' */

			case '\n': trailer (4, ' ');		/* "newline" */
				break;

			default:
				outchar(Char);		/* anything else */
		}
	}
	outchar(ETX);					/* ASCII ETX */
	outchar(EOT);					/* ASCII EOT */
}

/* Output all of the text in the current line buffer as an A record. A
backslash as the last character on the line suppresses the output of CR
LF. */

void
arecd() {


	outchar(NUL);					/* see 17 sep 99 mru */
	outchar(SOH);					/* ASCII SOH */
	outchar('A');					/* ASCII filetype */
	outchar(STX);					/* ASCII STX */
	for ( ; Char != EOF; new_char()) {
		switch (Char) {
			case '\\':
				new_char();		/* read next char, */
				switch (Char) {
				case 'r': outchar('\r'); break; /* CR */
				case 'n': outchar('\n'); break;
				case 'o': outchar(SO); break;	/* MOTOR OFF */
				case 'b': outchar(BEL); break;	/* ding */
				case '\n': break;	/* suppress newline */
				default:		/* \X ignored */
					break;
				}
				break;

			case '\n': outchar ('\r');	/* CR first (slow) */
				outchar ('\n'); 	/* LF time= CR delay */
				break;

			default:
				outchar(Char);		/* anything else */
		}
	}
	outchar(ETX);					/* ASCII ETX */
	outchar(EOT);					/* ASCII EOT */
}

/* Output all of the text in the current line buffer as an X record. This
suppresses newline. */

void
xrecd() {

	outchar(NUL);					/* see 17 sep 99 mru */
	outchar(SOH);					/* ASCII SOH */
	outchar('X');					/* ASCII filetype */
	outchar(STX);					/* ASCII STX */
	while (Char != EOF) {				/* write out text */
		if (Char != '\n') outchar(Char);
		new_char();
	}
	outchar(ETX);					/* ASCII ETX */
	outchar(EOT);					/* ASCII EOT */
}

/* Convert to speech and output a P record. */

void
precd() {

	outchar(NUL);					/* see 17 sep 99 mru */
	outchar(SOH);					/* ASCII SOH */
	outchar('P');					/* PHONEME filetype */
	outchar(STX);					/* ASCII STX */
	while (Char != EOF) {
		if (Char == '\\') {			/* if a meta-command, */
			new_char();
			switch (Char) {
				case 'p': outchar(EM); break;	/* PAUSE */
				case 'v': outchar(SUB); break;	/* LONGPAUSE */
				case 'r': outchar(DC2); break;	/* demo ON */
				case 't': outchar(DC4); break;	/* demo OFF */
			}
			new_char();				/* eat it */

		} else if (isdigit(Char)) 
			have_number();

		else if (isalpha(Char) || Char == '\'')
			have_letter();

		else if (is_punct(Char))
			have_punct();

		else if (Char == '$' && isdigit(Char1))
			have_dollars();

		else have_special();
	}
	outchar(ETX);					/* ASCII ETX */
	outchar(EOT);					/* ASCII EOT */
}


/* [tomj] Speak punctuation. Because punctuation is expressed only
as pauses in speaking, we suppress multiple punctuation characters,
speaking only the first one found. */

void
have_punct()
        {
	char buff[3];
	sprintf(buff, "%c ", Char);		/* find_rule() format, */
	find_rule(buff, 0, Rules[0]);		/* speak it (one character); */
	for (new_char(); is_punct(Char); new_char());
	}					/* throw away punctuation */



/* [tomj] Return true if the current character is punctuation. */


int
is_punct(c)
char c;
{
	switch (c) {
		case '.':
		case ',':
		case ':':
		case ';':
		case '!':
		case '?':
		case '-':
			return(TRUE);
		default:
			return(FALSE);
	}
}

void
have_dollars()
	{
	long int value;

	value = 0L;
	for (new_char() ; isdigit(Char) || Char == ',' ; new_char())
		{
		if (Char != ',')
			value = 10 * value + (Char-'0');
		}

	say_cardinal(value);	/* Say number of whole dollars */

	/* Found a character that is a non-digit and non-comma */

	/* Check for no decimal or no cents digits */
	if (Char != '.' || !isdigit(Char1))
		{
		if (value == 1L)
			outstring("dAAlER ");
		else
			outstring("dAAlAArz ");
		return;
		}

	/* We have '.' followed by a digit */

	new_char();	/* Skip the period */

	/* If it is ".dd " say as " DOLLARS AND n CENTS " */
	if (isdigit(Char1) && !isdigit(Char2))
		{
		if (value == 1L)
			outstring("dAAlER ");
		else
			outstring("dAAlAArz ");
		if (Char == '0' && Char1 == '0')
			{
			new_char();	/* Skip tens digit */
			new_char();	/* Skip units digit */
			return;
			}

		outstring("AAnd ");
		value = (Char-'0')*10 + Char1-'0';
		say_cardinal(value);

		if (value == 1L)
			outstring("sEHnt ");
		else
			outstring("sEHnts ");
		new_char();	/* Used Char (tens digit) */
		new_char();	/* Used Char1 (units digit) */
		return;
		}

	/* Otherwise say as "n POINT ddd DOLLARS " */

	outstring("pOYnt ");
	for ( ; isdigit(Char) ; new_char())
		{
		say_ascii(Char);
		}

	outstring("dAAlAArz ");

	return;
	}

void
have_special()
	{
/* This is not useful any more; it causes the processed output 
to have newlines where the source file does. 
	if (Char == '\n')
		outchar('\n');
	else
*/
	if (Char == '`') {
		++spellflag; spellflag &= 1;
	} else
	if (!isspace(Char))
		say_ascii(Char);

	new_char();
	return;
	}


void
have_number()
	{
	long int value;
	int lastdigit;

	value = Char - '0';
	lastdigit = Char;

	for (new_char() ; isdigit(Char) ; new_char())
		{
		value = 10 * value + (Char-'0');
		lastdigit = Char;
		}

	/* Recognize ordinals based on last digit of number */
	switch (lastdigit)
		{
	case '1':	/* ST */
		if (makeupper(Char) == 'S' && makeupper(Char1) == 'T' &&
		    !isalpha(Char2) && !isdigit(Char2))
			{
			say_ordinal(value);
			new_char();	/* Used Char */
			new_char();	/* Used Char1 */
			return;
			}
		break;

	case '2':	/* ND */
		if (makeupper(Char) == 'N' && makeupper(Char1) == 'D' &&
		    !isalpha(Char2) && !isdigit(Char2))
			{
			say_ordinal(value);
			new_char();	/* Used Char */
			new_char();	/* Used Char1 */
			return;
			}
		break;

	case '3':	/* RD */
		if (makeupper(Char) == 'R' && makeupper(Char1) == 'D' &&
		    !isalpha(Char2) && !isdigit(Char2))
			{
			say_ordinal(value);
			new_char();	/* Used Char */
			new_char();	/* Used Char1 */
			return;
			}
		break;

	case '0':	/* TH */
	case '4':	/* TH */
	case '5':	/* TH */
	case '6':	/* TH */
	case '7':	/* TH */
	case '8':	/* TH */
	case '9':	/* TH */
		if (makeupper(Char) == 'T' && makeupper(Char1) == 'H' &&
		    !isalpha(Char2) && !isdigit(Char2))
			{
			say_ordinal(value);
			new_char();	/* Used Char */
			new_char();	/* Used Char1 */
			return;
			}
		break;
		}

	say_cardinal(value);

	/* Recognize decimal points */
	if (Char == '.' && isdigit(Char1))
		{
		outstring("pOYnt ");
		for (new_char() ; isdigit(Char) ; new_char())
			{
			say_ascii(Char);
			}
		}

	/* Spell out trailing abbreviations */
	if (isalpha(Char))
		{
		while (isalpha(Char))
			{
			say_ascii(Char);
			new_char();
			}
		}

	return;
	}

void
have_letter()
	{
	char buff[MAX_LENGTH];
	int count;

	count = 0;
	buff[count++] = ' ';	/* Required initial blank */
	buff[count++] = makeupper(Char);

	for (new_char() ; isalpha(Char) || Char == '\'' ; new_char())
		{
		buff[count++] = makeupper(Char);
		if (count > MAX_LENGTH-2)
			{
			buff[count++] = ' ';
			buff[count++] = '\0';
			xlate_word(buff);	/* eat the over-full buffer */
			count = 1;
			}
		}

	buff[count++] = ' ';	/* Required terminating blank */
	buff[count++] = '\0';

	/* Check for AAANNN type abbreviations or spell-it-out mode */
	if (spellflag || isdigit(Char))
		{
		spell_word(buff);
		return;
		}
	else					/* [tomj] treat "A" and "I" as words */
	if ((strlen(buff) == 3) && (strcmp(buff, " I ") != 0) && (strcmp(buff, " A ") != 0)) 	 /* one character, two spaces */
		say_ascii(buff[1]);
	else
	if (Char == '.')		/* Possible abbreviation */
		abbrev(buff);
	else
		xlate_word(buff);

	if (Char == '-' && isalpha(Char1))
		new_char();	/* Skip hyphens */

	}

/* Handle abbreviations.  Text in buff was followed by '.' */
void
abbrev(buff)
	char buff[];
	{
	if (strcmp(buff, " DR ") == 0)
		{
		xlate_word(" DOCTOR ");
		new_char();
		}
	else
	if (strcmp(buff, " MR ") == 0)
		{
		xlate_word(" MISTER ");
		new_char();
		}
	else
	if (strcmp(buff, " MRS ") == 0)
		{
		xlate_word(" MISSUS ");
		new_char();
		}
	else
	if (strcmp(buff, " PHD ") == 0)
		{
		spell_word(" PHD ");
		new_char();
		}
	else
		xlate_word(buff);
	}

/* !!! end of PARSE.C */



/*
**	English to Phoneme translation.
**
**	Rules are made up of four parts:
**	
**		The left context.
**		The text to match.
**		The right context.
**		The phonemes to substitute for the matched text.
**
**	Procedure:
**
**		Seperate each block of letters (apostrophes included) 
**		and add a space on each side.  For each unmatched 
**		letter in the word, look through the rules where the 
**		text to match starts with the letter in the word.  If 
**		the text to match is found and the right and left 
**		context patterns also match, output the phonemes for 
**		that rule and skip to the next unmatched letter.
**
**
**	Special Context Symbols:
**
**		#	One or more vowels
**		:	Zero or more consonants
**		^	One consonant.
**		.	One of B, D, V, G, J, L, M, N, R, W or Z (voiced 
**			consonants)
**		%	One of ER, E, ES, ED, ING, ELY (a suffix)
**			(Right context only)
**		+	One of E, I or Y (a "front" vowel)
*/

int isvowel(chr)
	char chr;
	{
	return (chr == 'A' || chr == 'E' || chr == 'I' || 
		chr == 'O' || chr == 'U');
	}

int isconsonant(chr)
	char chr;
	{
	return (isupper(chr) && !isvowel(chr));
	}

void
xlate_word(word)
	char word[];
	{
	int index;	/* Current position in word */
	int type;	/* First letter of match part */


	index = 1;	/* Skip the initial blank */
	do
		{
		if (isupper(word[index]))
			type = word[index] - 'A' + 1;
		else
			type = 0;

		index = find_rule(word, index, Rules[type]);
		}
	while (word[index] != '\0');
	}

int
find_rule(word, index, rules)
	char word[];
	int index;
	Rule *rules;
	{
	Rule *rule;
	char *left, *match, *right, *output;
	int remainder;

	for (;;)	/* Search for the rule */
		{
		rule = rules++;
		match = (*rule)[1];

		if (match == 0)	/* bad symbol! */
			{
			fprintf(stderr,
"Error: Can't find rule for: '%c' in \"%s\"\n", word[index], word);
			return index+1;	/* Skip it! */
			}

		for (remainder = index; *match != '\0'; match++, remainder++)
			{
			if (*match != word[remainder])
				break;
			}

		if (*match != '\0')	/* found missmatch */
			continue;
/*
printf("\nWord: \"%s\", Index:%4d, Trying: \"%s/%s/%s\" = \"%s\"\n",
    word, index, (*rule)[0], (*rule)[1], (*rule)[2], (*rule)[3]);
*/
		left = (*rule)[0];
		right = (*rule)[2];

		if (!leftmatch(left, &word[index-1]))
			continue;
/*
printf("leftmatch(\"%s\",\"...%c\") succeded!\n", left, word[index-1]);
*/
		if (!rightmatch(right, &word[remainder]))
			continue;
/*
printf("rightmatch(\"%s\",\"%s\") succeded!\n", right, &word[remainder]);
*/
		output = (*rule)[3];
/*
printf("Success: ");
*/
		outstring(output);
		return remainder;
		}
	}


int
leftmatch(pattern, context)
	char *pattern;	/* first char of pattern to match in text */
	char *context;	/* last char of text to be matched */
	{
	char *pat;
	char *text;
	int count;

	if (*pattern == '\0')	/* null string matches any context */
		{
		return TRUE;
		}

	/* point to last character in pattern string */
	count = strlen(pattern);
	pat = pattern + (count - 1);

	text = context;

	for (; count > 0; pat--, count--)
		{
		/* First check for simple text or space */
		if (isalpha(*pat) || *pat == '\'' || *pat == ' ')
			if (*pat != *text)
				return FALSE;
			else
				{
				text--;
				continue;
				}

		switch (*pat)
			{
		case '#':	/* One or more vowels */
			if (!isvowel(*text))
				return FALSE;

			text--;

			while (isvowel(*text))
				text--;
			break;

		case ':':	/* Zero or more consonants */
			while (isconsonant(*text))
				text--;
			break;

		case '^':	/* One consonant */
			if (!isconsonant(*text))
				return FALSE;
			text--;
			break;

		case '.':	/* B, D, V, G, J, L, M, N, R, W, Z */
			if (*text != 'B' && *text != 'D' && *text != 'V'
			   && *text != 'G' && *text != 'J' && *text != 'L'
			   && *text != 'M' && *text != 'N' && *text != 'R'
			   && *text != 'W' && *text != 'Z')
				return FALSE;
			text--;
			break;

		case '+':	/* E, I or Y (front vowel) */
			if (*text != 'E' && *text != 'I' && *text != 'Y')
				return FALSE;
			text--;
			break;

		case '%':
		default:
			fprintf(stderr, "Bad char in left rule: '%c'\n", *pat);
			return FALSE;
			}
		}

	return TRUE;
	}


int
rightmatch(pattern, context)
	char *pattern;	/* first char of pattern to match in text */
	char *context;	/* last char of text to be matched */
	{
	char *pat;
	char *text;

	if (*pattern == '\0')	/* null string matches any context */
		return TRUE;

	pat = pattern;
	text = context;

	for (pat = pattern; *pat != '\0'; pat++)
		{
		/* First check for simple text or space */
		if (isalpha(*pat) || *pat == '\'' || *pat == ' ')
			if (*pat != *text)
				return FALSE;
			else
				{
				text++;
				continue;
				}

		switch (*pat)
			{
		case '#':	/* One or more vowels */
			if (!isvowel(*text))
				return FALSE;

			text++;

			while (isvowel(*text))
				text++;
			break;

		case ':':	/* Zero or more consonants */
			while (isconsonant(*text))
				text++;
			break;

		case '^':	/* One consonant */
			if (!isconsonant(*text))
				return FALSE;
			text++;
			break;

		case '.':	/* B, D, V, G, J, L, M, N, R, W, Z */
			if (*text != 'B' && *text != 'D' && *text != 'V'
			   && *text != 'G' && *text != 'J' && *text != 'L'
			   && *text != 'M' && *text != 'N' && *text != 'R'
			   && *text != 'W' && *text != 'Z')
				return FALSE;
			text++;
			break;

		case '+':	/* E, I or Y (front vowel) */
			if (*text != 'E' && *text != 'I' && *text != 'Y')
				return FALSE;
			text++;
			break;

		case '%':	/* ER, E, ES, ED, ING, ELY (a suffix) */
			if (*text == 'E')
				{
				text++;
				if (*text == 'L')
					{
					text++;
					if (*text == 'Y')
						{
						text++;
						break;
						}
					else
						{
						text--; /* Don't gobble L */
						break;
						}
					}
				else
				if (*text == 'R' || *text == 'S' 
				   || *text == 'D')
					text++;
				break;
				}
			else
			if (*text == 'I')
				{
				text++;
				if (*text == 'N')
					{
					text++;
					if (*text == 'G')
						{
						text++;
						break;
						}
					}
				return FALSE;
				}
			else
			return FALSE;

		default:
			fprintf(stderr, "Bad char in right rule:'%c'\n", *pat);
			return FALSE;
			}
		}

	return TRUE;
	}

/* !!!! End of PHONEME.C */


/*
**              Integer to Readable ASCII Conversion Routine.
**
** Synopsis:
**
**      say_cardinal(value)
**      	long int     value;          -- The number to output
**
**	The number is translated into a string of phonemes
**
*/

static char *Cardinals[] = 
	{
	"zIHrOW ",	"wAHn ",	"tUW ",		"THrIY ",
	"fOWr ",	"fAYv ",	"sIHks ",	"sEHvAXn ",
	"EYt ",		"nAYn ",		
	"tEHn ",	"IYlEHvAXn ",	"twEHlv ",	"THERtIYn ",
	"fOWrtIYn ",	"fIHftIYn ", 	"sIHkstIYn ",	"sEHvEHntIYn ",
	"EYtIYn ",	"nAYntIYn "
	} ;

static char *Twenties[] = 
	{
	"twEHntIY ",	"THERtIY ",	"fAOrtIY ",	"fIHftIY ",
	"sIHkstIY ",	"sEHvEHntIY ",	"EYtIY ",	"nAYntIY "
	} ;

static char *Ordinals[] = 
	{
	"zIHrOWEHTH ",	"fERst ",	"sEHkAHnd ",	"THERd ",
	"fOWrTH ",	"fIHfTH ",	"sIHksTH ",	"sEHvEHnTH ",
	"EYtTH ",	"nAYnTH ",		
	"tEHnTH ",	"IYlEHvEHnTH ",	"twEHlvTH ",	"THERtIYnTH ",
	"fAOrtIYnTH ",	"fIHftIYnTH ", 	"sIHkstIYnTH ",	"sEHvEHntIYnTH ",
	"EYtIYnTH ",	"nAYntIYnTH "
	} ;

static char *Ord_twenties[] = 
	{
	"twEHntIYEHTH ","THERtIYEHTH ",	"fOWrtIYEHTH ",	"fIHftIYEHTH ",
	"sIHkstIYEHTH ","sEHvEHntIYEHTH ","EYtIYEHTH ",	"nAYntIYEHTH "
	} ;


/*
** Translate a number to phonemes.  This version is for CARDINAL numbers.
**	 Note: this is recursive.
*/
void
say_cardinal(value)
	long int value;
	{
	if (value < 0)
		{
		outstring("mAYnAHs ");
		value = (-value);
		if (value < 0)	/* Overflow!  -32768 */
			{
			outstring("IHnfIHnIHtIY ");
			return;
			}
		}

	if (value >= 1000000000L)	/* Billions */
		{
		say_cardinal(value/1000000000L);
		outstring("bIHlIYAXn ");
		value = value % 1000000000;
		if (value == 0)
			return;		/* Even billion */
		if (value < 100)	/* as in THREE BILLION AND FIVE */
			outstring("AEnd ");
		}

	if (value >= 1000000L)	/* Millions */
		{
		say_cardinal(value/1000000L);
		outstring("mIHlIYAXn ");
		value = value % 1000000L;
		if (value == 0)
			return;		/* Even million */
		if (value < 100)	/* as in THREE MILLION AND FIVE */
			outstring("AEnd ");
		}

	/* Thousands 1000..1099 2000..99999 */
	/* 1100 to 1999 is eleven-hunderd to ninteen-hunderd */
	if ((value >= 1000L && value <= 1099L) || value >= 2000L)
		{
		say_cardinal(value/1000L);
		outstring("THAWzAEnd ");
		value = value % 1000L;
		if (value == 0)
			return;		/* Even thousand */
		if (value < 100)	/* as in THREE THOUSAND AND FIVE */
			outstring("AEnd ");
		}

	if (value >= 100L)
		{
		outstring(Cardinals[value/100]);
		outstring("hAHndrEHd ");
		value = value % 100;
		if (value == 0)
			return;		/* Even hundred */
		}

	if (value >= 20)
		{
		outstring(Twenties[(value-20)/ 10]);
		value = value % 10;
		if (value == 0)
			return;		/* Even ten */
		}

	outstring(Cardinals[value]);
	return;
	} 


/*
** Translate a number to phonemes.  This version is for ORDINAL numbers.
**	 Note: this is recursive.
*/
void
say_ordinal(value)
	long int value;
	{

	if (value < 0)
		{
		outstring("mAHnAXs ");
		value = (-value);
		if (value < 0)	/* Overflow!  -32768 */
			{
			outstring("IHnfIHnIHtIY ");
			return;
			}
		}

	if (value >= 1000000000L)	/* Billions */
		{
		say_cardinal(value/1000000000L);
		value = value % 1000000000;
		if (value == 0)
			{
			outstring("bIHlIYAXnTH ");
			return;		/* Even billion */
			}
		outstring("bIHlIYAXn ");
		if (value < 100)	/* as in THREE BILLION AND FIVE */
			outstring("AEnd ");
		}

	if (value >= 1000000L)	/* Millions */
		{
		say_cardinal(value/1000000L);
		value = value % 1000000L;
		if (value == 0)
			{
			outstring("mIHlIYAXnTH ");
			return;		/* Even million */
			}
		outstring("mIHlIYAXn ");
		if (value < 100)	/* as in THREE MILLION AND FIVE */
			outstring("AEnd ");
		}

	/* Thousands 1000..1099 2000..99999 */
	/* 1100 to 1999 is eleven-hunderd to ninteen-hunderd */
	if ((value >= 1000L && value <= 1099L) || value >= 2000L)
		{
		say_cardinal(value/1000L);
		value = value % 1000L;
		if (value == 0)
			{
			outstring("THAWzAEndTH ");
			return;		/* Even thousand */
			}
		outstring("THAWzAEnd ");
		if (value < 100)	/* as in THREE THOUSAND AND FIVE */
			outstring("AEnd ");
		}

	if (value >= 100L)
		{
		outstring(Cardinals[value/100]);
		value = value % 100;
		if (value == 0)
			{
			outstring("hAHndrEHdTH ");
			return;		/* Even hundred */
			}
		outstring("hAHndrEHd ");
		}

	if (value >= 20)
		{
		if ((value%10) == 0)
			{
			outstring(Ord_twenties[(value-20)/ 10]);
			return;		/* Even ten */
			}
		outstring(Twenties[(value-20)/ 10]);
		value = value % 10;
		}

	outstring(Ordinals[value]);
	return;
	} 


/* !!!! End of SAYNUM.C */


/* [tomj] These tables were modified to make the speech less explicit and more colloquial
eg. "PAREN" instead of "OPEN PAREN". */

static char *Ascii[] =
	{

/* Control codes, 0 - 31 decimal */
"nUWl ","stAArt AXv hEHdER ","stAArt AXv tEHkst ","EHnd AXv tEHkst ",
"EHnd AXv trAEnsmIHSHAXn",
"EHnkwAYr ","AEk ","bEHl ","bAEkspEYs ","tAEb ","lIHnIYfIYd ",
"vERtIHkAXl tAEb ","fAOrmfIYd ","kAErAYj rIYtERn ","SHIHft AWt ",
"SHIHft IHn ","dIHlIYt ","dIHvIHs kAAntrAAl wAHn ","dIHvIHs kAAntrAAl tUW ",
"dIHvIHs kAAntrAAl THrIY ","dIHvIHs kAAntrAAl fOWr ","nAEk ","sIHnk ",
"EHnd tEHkst blAAk ","kAEnsEHl ","EHnd AXv mEHsIHj ","sUWbstIHtUWt ",
"EHskEYp ","fAYEHld sIYpERAEtER ","grUWp sIYpERAEtER ","rIYkAOrd sIYpERAEtER ",
"yUWnIHt sIYpERAEtER ",


"spEYs ","bAENG ","kwOWt ",
"nUWmbER ","dAAlER sAYn ","pERsEHnt ","AXnd ","kwOWt ",
"pEHrEHn ","pEHrEHn ","stAAr ","plAHs ","kAAmmAX ",
"mIHnAHs ","pIYrIYAAd ","slAESH ",

"zIHrOW ","wAHn ","tUW ","THrIY ","fOWr ",
"fAYv ","sIHks ","sEHvAXn ","EYt ","nAYn ",

"kAAlAXn ","sEHmIP1HkAAlAXn ","lEHs DHAEn ","EHkwAXls ","grEYtER DHAEn ",
"kwEHsCHAXn mAArk ","P2AEt ",

"EY ","bIY ","sIY ","dIY ","IY ","EHf ","jIY  ",
"EYtCH ","AY ","jEY ","kEY ","EHl ","EHm ","EHn ","OW ","pIY ",
"kY1UW ","AAr ","EHz ","tIY ","yU1 ","vIY ",
"dAHblyUWw ","EHks ","wAYIY ","zIY ",

"lEHft brAEkEHt ","bAEkslAESH ","rAYt brAEkEHt ","kAErEHt ",
"AHndERskAOr ","AEpAAstrAAfIH ",

"EY ","bIY ","sIY ","dIY ","IY ","EHf ","jIY  ",
"EYtCH ","AY ","jEY ","kEY ","EHl ","EHm ","EHn ","OW ","pIY ",
"kY1 ","AAr ","EHz ","tIY ","yU1 ","vIY ",
"dAHblyUWw ","EHks ","wAYIY ","zIY ",

"lEHft brEYs ","vERtIHkAXl bAAr ","rAYt brEYs ","tAYld ","dEHl ",
	};

void
say_ascii(character)
	int character;
	{
	outstring(Ascii[character&0x7F]);
	outstring("P4 ");
	}

void
spell_word(word)
	char *word;
	{
	for (word++ ; word[1] != '\0' ; word++)
	{
		outstring(Ascii[(*word)&0x7F]);
		outstring("P5P5 ");
	}
	}


/* !!!! End of SPELLWOR.C */


