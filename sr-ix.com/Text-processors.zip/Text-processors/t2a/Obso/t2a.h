/* Prototypes created for t2a.c */

/* new functions */
int readchar(void);
void srecd(void);
void trecd(void);
void xrecd(void);
void arecd(void);
void precd(void);
void punch(char);
void trailer(int, char);
int is_punct(char);
void have_punct(void);

typedef char *Rule[4];	/* A rule is four character pointers */


void outstring(char *);
void outchar(int);
int makeupper(int);
char new_char(void);
void xlate_file(void);
void have_dollars(void);
void have_special(void);
void have_number(void);
void have_letter(void);
void abbrev(char *);
int isvowel(char);
int isconsonant(char);
void xlate_word(char *);
int find_rule(char *, int, Rule *);
int leftmatch(char *, char *);
int rightmatch(char *, char *);
void say_cardinal(long int);
void say_ordinal(long int);
void say_ascii(int);
void spell_word(char *);

